package co.simplon;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Writer implements IWriter{

	private String filename;

    private Path path;

    private String content;


    public Writer(String filename) {

        this.filename = filename;

    }


    public void start() {

        path = Paths.get(filename);

        content = "";

    }


    public void writeLine(String line) {

        content += line + "%n";

    }


    public void stop() {

        try {

            Files.write(path, String.format(content).getBytes());

        } catch (IOException e) {

            System.err.println("Impossible de rédiger la facture");

        }

    }
}
